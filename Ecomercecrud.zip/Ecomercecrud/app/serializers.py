from rest_framework import serializers


class ProductSerializer(serializers.Serializer):
    name = serializers.CharField(required = True)
    price = serializers.FloatField(required=True)
    description = serializers.CharField(required=True)
