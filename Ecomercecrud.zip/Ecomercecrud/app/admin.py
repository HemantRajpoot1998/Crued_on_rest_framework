from django.contrib import admin

# Register your models here.
from app.models import Product

class ProductAdmin(admin.ModelAdmin):
    list_display = ['name','price','description','is_active','added_on']

admin.site.register(Product,ProductAdmin)
