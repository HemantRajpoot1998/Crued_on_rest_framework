from django.urls import path

from app.views import *

urlpatterns = [
    path('add_product',AddProduct.as_view(),name='add_product'),
    path('update_data/<int:id>',UpdateProduct.as_view(),name='update_data')


]