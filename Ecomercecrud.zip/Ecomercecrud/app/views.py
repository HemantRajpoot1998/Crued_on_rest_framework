from apiview import serializer
from django.shortcuts import render

# Create your views here.
from django.views.decorators.csrf import csrf_exempt
from rest_framework import request, status
from rest_framework.authentication import SessionAuthentication
from rest_framework.views import APIView
from rest_framework.response import Response

from app.models import Product
from app.serializers import ProductSerializer

from rest_framework.authentication import SessionAuthentication, BasicAuthentication

class CsrfExemptSessionAuthentication(SessionAuthentication):

    def enforce_csrf(self, request):
        return  # To not perform the csrf check previously happening

class AddProduct(APIView):
    def post(self,request,*args,**kwrgs):
        data = request.data
        serializers = ProductSerializer(data=data)
        if serializers.is_valid():
            pname = serializers.validated_data['name']
            pprice = serializers.validated_data['price']
            pdiscrb = serializers.validated_data['description']
            Product.objects.create(name=pname,price=pprice,description=pdiscrb)
            return Response({"status": "data created"})

        else:
            return Response({"msg":"something went wrong"})

    def get(self,request,*args,**kwrgs):
        pro_obj=Product.objects.filter().values('name','price','description')

        return Response({"data":pro_obj})

class UpdateProduct(APIView):
    def post(self,request,id,*args,**kwargs):
        data = request.data
        serializers = ProductSerializer(data=data)
        if serializers.is_valid():
            pname = serializers.validated_data['name']
            pprice = serializers.validated_data['price']
            pdiscrb = serializers.validated_data['description']
            pro_ob=Product.objects.filter(id=id).update(name=pname, price=pprice, description=pdiscrb)

            return Response({"msg":"data updated successfuly"})
        else:
            return Response(status=status.HTTP_404_NOT_FOUND)

    def get(self, request,id,*args,**kwargs):
        product_obj=Product.objects.filter(id=id)
        product_obj.delete()
        return Response({"msg":"data deleted"})



