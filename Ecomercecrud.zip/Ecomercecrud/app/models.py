from django.db import models

# Create your models here.

class Product(models.Model):
    name = models.CharField(max_length=255)
    price = models.FloatField(default=0)
    description = models.TextField()
    is_active = models.BooleanField(default=True)
    added_on = models.DateTimeField(auto_now_add=True)
